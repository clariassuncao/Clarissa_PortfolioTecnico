package com.example.urna_trabalhotecnico;

public class Candidato {
    String nome, numero, cargo;
    int qtdVotos;

    public Candidato(String nome, String numero, String cargo, int qtdVotos) {
        this.nome = nome;
        this.numero = numero;
        this.cargo = cargo;
        this.qtdVotos = qtdVotos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public int getQtdVotos() {
        return qtdVotos;
    }

    public void setQtdVotos(int qtdVotos) {
        this.qtdVotos = qtdVotos;
    }
}
