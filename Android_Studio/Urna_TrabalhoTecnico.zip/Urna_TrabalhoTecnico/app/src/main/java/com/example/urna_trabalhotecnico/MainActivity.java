package com.example.urna_trabalhotecnico;

import static java.lang.Integer.parseInt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText cpf, numCandidato;
    TextView cargo, nome;
    ArrayList<Candidato> lCandidato = new ArrayList<>();
    ArrayList<String> eleitores = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        cpf = findViewById(R.id.cpfEleitor);
        numCandidato = findViewById(R.id.numCanditado);
        nome = findViewById(R.id.nome);
        cargo = findViewById(R.id.cargo);
        criaCanditados();
    }

    @Override
    protected void onStart() {
        super.onStart();

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Urna eletrônica")
                .child("Eleitores");

        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot snap : snapshot.getChildren()){
                    eleitores.add(snap.getValue().toString());

                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void criaCanditados(){
        Candidato eduarda = new Candidato("Eduarda", "Presidente", "20", 0);
        Candidato theo = new Candidato("Théo", "Presidente", "25", 0);
        Candidato manu = new Candidato("Manu", "Presidente", "23",0 );
        Candidato mariah = new Candidato("Mariah", "Presidente", "16",0);
        Candidato ester = new Candidato("Ester", "Presidente", "28", 0);
        Candidato thais = new Candidato("Thais", "Presidente", "35",0);
        Candidato clarissa = new Candidato("Clarissa", "Presidente", "13", 0);
        Candidato nulo = new Candidato("NULO", "Presidente", "", 0);
        lCandidato.add(eduarda);
        lCandidato.add(theo);
        lCandidato.add(manu);
        lCandidato.add(mariah);
        lCandidato.add(ester);
        lCandidato.add(thais);
        lCandidato.add(clarissa);
        lCandidato.add(nulo);
    }

    public void verifica(View h){
        for (Candidato c : lCandidato){
            if (numCandidato.equals(c.numero)){
                String nomeDoCandidato = c.getNome();
                nome.setText(nomeDoCandidato);
                cargo.setText(c.getCargo());
            }
        }
    }


    public void confirma(View f){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference()
                .child("Urna eletrônica")
                .child("Eleitores");
        String cpfEleitor = cpf.getText().toString();

        if (eleitores.isEmpty()){
            eleitores.add(cpfEleitor);
            reference.setValue(eleitores).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Toast.makeText(MainActivity.this, "CPF não cadastrado, pode votar!", Toast.LENGTH_LONG).show();
                    int numero = parseInt(numCandidato.getText().toString());

                    switch (numero) {
                        case 20:
                            DatabaseReference reference01 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Eduarda");
                            reference01.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;

                        case 25:
                            DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Théo");
                            reference1.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference1.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference1.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;

                        case 23:
                            DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Manu");
                            reference2.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference2.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference2.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;

                        case 16:
                            DatabaseReference reference3 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Mariah");
                            reference3.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference3.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference3.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;

                        case 28:
                            DatabaseReference reference4 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Ester");
                            reference4.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference4.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference4.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;

                        case 35:
                            DatabaseReference reference5 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Thais");
                            reference5.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference5.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference5.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;

                        case 13:
                            DatabaseReference reference6 = FirebaseDatabase.getInstance().getReference()
                                    .child("Urna eletrônica")
                                    .child("Candidatos")
                                    .child("Número de votos")
                                    .child("Clarissa");
                            reference6.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if (snapshot.exists()) {
                                        int qtd = parseInt(snapshot.getValue().toString());
                                        qtd = qtd + 1;
                                        reference6.setValue(qtd);
                                    } else {
                                        int qtd = 1;
                                        reference6.setValue(qtd);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                            break;
                    }
                }
            });
        } else {
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    String eleitoresBD = snapshot.getValue().toString();
                    if (eleitoresBD.contains(cpfEleitor)){
                        Toast.makeText(MainActivity.this, "Este eleitor já votou!", Toast.LENGTH_LONG).show();
                    }else {
                        eleitores.add(cpfEleitor);
                        reference.setValue(eleitores).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(MainActivity.this, "CPF não cadastrado, pode votar!", Toast.LENGTH_LONG).show();
                                int numero = parseInt(numCandidato.getText().toString());

                                switch (numero) {
                                    case 20:
                                        DatabaseReference reference01 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Eduarda");
                                        reference01.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;

                                    case 25:
                                        DatabaseReference reference1 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Théo");
                                        reference1.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference1.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference1.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;

                                    case 23:
                                        DatabaseReference reference2 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Manu");
                                        reference2.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference2.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference2.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;

                                    case 16:
                                        DatabaseReference reference3 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Mariah");
                                        reference3.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference3.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference3.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;

                                    case 28:
                                        DatabaseReference reference4 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Ester");
                                        reference4.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference4.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference4.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;

                                    case 35:
                                        DatabaseReference reference5 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Thais");
                                        reference5.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference5.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference5.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;

                                    case 13:
                                        DatabaseReference reference6 = FirebaseDatabase.getInstance().getReference()
                                                .child("Urna eletrônica")
                                                .child("Candidatos")
                                                .child("Número de votos")
                                                .child("Clarissa");
                                        reference6.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                if (snapshot.exists()) {
                                                    int qtd = parseInt(snapshot.getValue().toString());
                                                    qtd = qtd + 1;
                                                    reference6.setValue(qtd);
                                                } else {
                                                    int qtd = 1;
                                                    reference6.setValue(qtd);
                                                }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });
                                        break;
                                }
                            }
                        });
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Toast.makeText(MainActivity.this, "Não foi possível conectar com o banco de dados", Toast.LENGTH_SHORT).show();
                }
            });
        }

        }
    }
