package com.example.healthcare;

public class AdapterClinicasVinculadas {
}
