package com.example.healthcare;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class TelaMedicamentos_add extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_medicamentos_add);
    }
}