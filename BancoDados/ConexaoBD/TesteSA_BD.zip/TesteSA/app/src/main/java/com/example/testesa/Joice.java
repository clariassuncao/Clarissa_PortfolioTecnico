package com.example.testesa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Joice extends AppCompatActivity {
EditText email, senha;
    Usuarios u = new Usuarios();
    String mensagem = "Teste";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.joice);
        getSupportActionBar().hide();
        email = findViewById(R.id.email);
        senha = findViewById(R.id.senha);
    }
    public void cadastra(View v){
    String e = email.getText().toString();
    int s = Integer.parseInt(senha.getText().toString());
    Usuarios u = new Usuarios(e,s);
    u.salvar_bd();
    }

    public void print(String e){
        Toast.makeText(this, e, Toast.LENGTH_SHORT).show();
    }

    public void login(View v){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Usuarios");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String e = email.getText().toString();
                int s = Integer.parseInt(senha.getText().toString());
                boolean teste = false;
                for (DataSnapshot usuario : snapshot.getChildren()) {
                    if (usuario.getValue(Usuarios.class).getEmail().equals(e) && usuario.getValue(Usuarios.class).getSenha() == s) {
                        print("Usuário existe");
                        teste = true;
                        break;
                    }
                }

                if(teste == false) {
                    print("Usuário");
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}