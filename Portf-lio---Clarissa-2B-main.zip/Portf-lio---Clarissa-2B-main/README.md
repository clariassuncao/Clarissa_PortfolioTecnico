#Portfólio | Técnico Desinvolvimento de Sistemas 


<b>CLARISSA GONÇALVES DE ASSUNÇÃO</b>

clarissa.g.a@hotmail.com 
  
  
Celular: (48) 9 9670 8200
  

<b>Formação</b>


Cursando o 2° ano do Ensino Médio


Cursando Técnico em Desinvolvimentos de Sistemas 


<b>Cursos Complementares</b>

_____________________________________________________________________________________________________________________________

Excel Básico - SENAC

Mundo do Trabalho - SENAI

Assistente adminitrativo - IDES


<b>Experiência Profissional</b>

_____________________________________________________________________________________________________________________________


Venda de docinhos (autônoma)

Jovem aprendiz RH - Dental Speed

Jovem aprendiz SESMT - Intelbras 


<b>Qualidades</b>

_____________________________________________________________________________________________________________________________



Empatia 


Criativa

 
Proativa 
